package com.example;

/**
 * implementation of truck program 
 *
 */
import java.util.*;

class Truck {
    String garbageType;
    int numberOfBags = 0;
    int farthestHouse = 0;

    public void setType(String type) {
        this.garbageType = type;
    }

    public String getType() {
        return garbageType;
    }

    // Finds the max distance for the truck to travel
    public void setMaxPotDist(int dist) {
        this.farthestHouse = dist;

    }

    public int getMaxPotDist() {
        return farthestHouse;
    }
}

class Garbage {
    HashMap<Character, Integer> occurrences = new HashMap<Character, Integer>();

    public void setOccurences(String T) {
        for (int i = 0; i < T.length(); i++) {
            if (!this.occurrences.containsKey(T.charAt(i))) {
                occurrences.put(T.charAt(i), 1);
            } else {
                int bags = occurrences.get(T.charAt(i));
                bags++;
                occurrences.put(T.charAt(i), bags);
            }
        }
    }

}

public class Solution {
    public static int solve(int[] D, String[] T) {
        // each home has a hashmap with trash types and occurrences
        ArrayList<Garbage> homes = new ArrayList<Garbage>();
        // trucks with typing, max potential distance, and the amount of bags it had to
        // collect
        ArrayList<Truck> convoy = new ArrayList<Truck>();
        // Scalable Array for types of garbage
        String[] types = { "G", "P", "M" };
        List<String> typesList = new ArrayList<String>(Arrays.asList(types));
        List<String> typeCheck = new ArrayList<String>(Arrays.asList(types));
        // truck distances for comparison
        ArrayList<Integer> distances = new ArrayList<Integer>();
        HashMap<Character, Integer> maxPotDist = new HashMap<Character, Integer>();
        // hashtable for all potential distances so we only go through D once
        for (int i = 0; i < D.length; i++) {
            for (int j = 0; j < typesList.size(); j++) {
                if (T[i].contains(typesList.get(j))) {
                    maxPotDist.put(typesList.get(j).charAt(0), i + 1);
                    // list to remember missing types of garbage
                    typeCheck.remove(typesList.get(j));
                }
            }

        }
        // puts the rest of the types as max dist of 0 since theres no types of that
        // trash on the route
        for (int k = 0; k < typeCheck.size(); k++) {
            maxPotDist.put(typeCheck.get(k).charAt(0), 0);
        }

        // initialize list of houses + hashmaps
        for (int i = 0; i < T.length; i++) {
            Garbage house = new Garbage();
            house.setOccurences(T[i]);
            homes.add(house);
        }
        // initialize our group of trucks
        for (int i = 0; i < types.length; i++) {
            Truck truck = new Truck();
            truck.setType(types[i]);
            truck.setMaxPotDist(maxPotDist.get(types[i].charAt(0)));
            convoy.add(truck);
        }
        // i = trucknumber, j = house number
        for (int i = 0; i < types.length; i++) {
            //
            Truck current = convoy.get(i);
            int distanceTraveled = 0;
            for (int j = 0; j < current.farthestHouse; j++) {
                HashMap<Character, Integer> garbageHash = homes.get(j).occurrences;
                if (garbageHash.containsKey(current.garbageType.charAt(0))) {
                    current.numberOfBags += garbageHash.get(current.garbageType.charAt(0));

                }
                distanceTraveled += D[j];
            }
            distances.add(current.numberOfBags + distanceTraveled * 2);
        }
        return Collections.max(distances);
    }

    public static void main(String[] args) {

    }

}
