package com.example;

import static org.junit.Assert.assertTrue;

import javax.swing.plaf.ScrollBarUI;

import org.junit.Test;

import org.junit.Assert;;

/**
 * 
 * All tests are assumed that there are 3 types of garbage, will work if more
 * are added to the types array in Solution.solve
 */
public class AppTest {
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue() {
        assertTrue(true);
    }

    // NULL TEST
    @Test
    public void nullTest() {
        final int[] D = {};
        final String[] T = {};
        final int expected = 0;
        final int actual = Solution.solve(D, T);
        Assert.assertEquals(expected, actual);
    }

    // test to see if regular input is working
    @Test
    public void simpleTest() {
        final int[] D = { 1, 2 };
        final String[] T = { "GP", "GM" };
        final int expected = 8;
        final int actual = Solution.solve(D, T);
        Assert.assertEquals(expected, actual);
    }

    // test if far end of house is the only one that throws garbage out
    @Test
    public void endTest() {
        final int[] D = { 1, 1, 1, 1, 1, 5 };
        final String[] T = { "", "", "", "", "", "M" };
        final int expected = 21;
        final int actual = Solution.solve(D, T);
        Assert.assertEquals(expected, actual);
    }

    // test for tie
    @Test
    public void tieTest() {
        final int[] D = { 1, 1, 1 };
        final String[] T = { "", "PPP", "M" };
        final int expected = 7;
        final int actual = Solution.solve(D, T);
        Assert.assertEquals(expected, actual);
    }

    @Test
    // more bags of garbage vs farther distance
    public void quantityTest() {
        final int[] D = { 1, 1, 1 };
        final String[] T = { "PP", "PP", "M" };
        final int expected = 8;
        final int actual = Solution.solve(D, T);
        Assert.assertEquals(expected, actual);
    }

    @Test
    // now if farther distance is higher
    public void quantityTestTwo() {
        final int[] D = { 1, 1, 1, 1 };
        final String[] T = { "", "PPPP", "M", "G" };
        final int expected = 9;
        final int actual = Solution.solve(D, T);
        Assert.assertEquals(expected, actual);
    }

    @Test
    // combination of the two
    public void quantityTestThree() {
        final int[] D = { 1, 1, 1, 1 };
        final String[] T = { "G", "PPPP", "M", "G" };
        final int expected = 10;
        final int actual = Solution.solve(D, T);
        Assert.assertEquals(expected, actual);
    }
}
